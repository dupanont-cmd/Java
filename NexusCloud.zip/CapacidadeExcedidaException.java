/**
 * Exceção CHECKED (RN03 - regra 2).
 * Estende Exception (e não RuntimeException): o compilador OBRIGA quem chama
 * o método a tratar (try-catch) ou propagar (throws).
 * Lançada quando a RAM necessária ultrapassa a RAM total do servidor.
 */
public class CapacidadeExcedidaException extends Exception {

    // Construtor recebe a mensagem e repassa para a classe pai (Exception)
    public CapacidadeExcedidaException(String msg) {
        super(msg);
    }
}
// RA: ______________ (preencha com o seu RA)
