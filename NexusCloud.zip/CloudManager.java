import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Banco de dados principal da NexusCloud (RN02) + auditoria financeira (RN04).
 */
public class CloudManager {

    // RN02: Map (interface) instanciado com HashMap (implementação baseada em Hash).
    // Chave = Cliente | Valor = Set de Servidores (HashSet: sem duplicatas e sem ordem específica).
    private Map<Cliente, Set<Servidor>> bancoDeDados = new HashMap<>();

    // Construtor padrão (o banco já nasce inicializado na declaração)
    public CloudManager() {
    }

    /** Registra o cliente com um conjunto vazio de servidores (não sobrescreve se já existir). */
    public void registrarCliente(Cliente c) {
        bancoDeDados.putIfAbsent(c, new HashSet<>());
    }

    /**
     * Associa um servidor a um cliente.
     * computeIfAbsent garante que exista um Set para o cliente (mesmo se não registrado antes);
     * add() em um HashSet ignora duplicatas pelo equals/hashCode (IP).
     */
    public void provisionarServidor(Cliente c, Servidor s) {
        bancoDeDados.computeIfAbsent(c, chave -> new HashSet<>()).add(s);
    }

    /**
     * RN04 - Fatura ativa do cliente, usando Streams (sem laço for):
     * pega o Set de servidores do cliente (ou vazio, se não existir) -> filtra só os LIGADOS
     * -> extrai o preço por hora -> soma.
     */
    public double calcularFaturaAtiva(Cliente c) {
        return bancoDeDados.getOrDefault(c, new HashSet<>())
                .stream()
                .filter(Servidor::isStatusLigado)
                .mapToDouble(Servidor::getPrecoPorHora)
                .sum();
    }
}
// RA: ______________ (preencha com o seu RA)
