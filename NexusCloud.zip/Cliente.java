import java.util.Objects;

/**
 * POJO Cliente (RN01).
 * Identidade lógica: dois clientes são iguais se tiverem o mesmo CPF.
 */
public class Cliente {

    // Atributos privados (encapsulamento rigoroso)
    private String cpf;
    private String nome;

    // Construtor conforme o diagrama UML
    public Cliente(String cpf, String nome) {
        this.cpf = cpf;
        this.nome = nome;
    }

    // Getters conforme o diagrama (getCpf e getNome)
    public String getCpf() {
        return cpf;
    }

    public String getNome() {
        return nome;
    }

    // Setters necessários (RN01 pede getters/setters necessários)
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    /** equals baseado SOMENTE no CPF (regra de identidade). */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;                       // mesmo objeto na memória
        if (obj == null || getClass() != obj.getClass()) return false; // nulo ou outra classe
        Cliente outro = (Cliente) obj;                      // cast seguro após a checagem
        return Objects.equals(cpf, outro.cpf);              // compara o CPF (null-safe)
    }

    /** hashCode usa o MESMO campo do equals (contrato equals/hashCode). Essencial para usar Cliente como chave do HashMap. */
    @Override
    public int hashCode() {
        return Objects.hash(cpf);
    }

    @Override
    public String toString() {
        return nome + " (" + cpf + ")";
    }
}
// RA: ______________ (preencha com o seu RA)
