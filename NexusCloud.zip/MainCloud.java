/**
 * Campo de testes (roteiro dos 10 passos). A main declara "throws Exception" apenas
 * para o passo 8, que chama um método checked fora de try-catch conforme o roteiro.
 */
public class MainCloud {

    public static void main(String[] args) throws Exception {

        // Passo 1: instancia o CloudManager
        CloudManager manager = new CloudManager();

        // Passo 2: instancia 1 Cliente
        Cliente cliente = new Cliente("111.222.333-44", "Wayne Enterprises");

        // Passo 3: instancia 1 Servidor (IP, RAM total 16.0 GB, preço R$ 5.50/h)
        Servidor servidor = new Servidor("192.168.0.1", 16.0, 5.50);

        // Passo 4: registra o cliente no banco do Manager e adiciona o servidor a ele
        manager.registrarCliente(cliente);
        manager.provisionarServidor(cliente, servidor);

        // Passo 5: instancia 2 Containers diferentes
        Container c1 = new Container("C-01", "App Web", 10.0);
        Container c2 = new Container("C-02", "Banco de Dados", 8.0);

        // Passo 6: Teste Falha Unchecked. O servidor nasce desligado, então a
        // ServidorOfflineException estoura (sem try-catch, de propósito).
        // >>> Descomente a linha abaixo para ver o "crash" proposital; depois comente de novo (Passo 7). <<<
        // servidor.alocarContainer(c1);

        // Passo 7: Siga em frente - linha do passo 6 comentada; liga o servidor
        servidor.ligar();

        // Passo 8: aloca o Container 1 com sucesso (10.0 de 16.0 GB)
        servidor.alocarContainer(c1);
        System.out.println("Container " + c1.getId() + " alocado com sucesso! RAM em uso: "
                + servidor.calcularRamEmUso() + " GB");

        // Passo 9: Teste Falha Checked. 10.0 + 8.0 = 18.0 > 16.0, então estoura a
        // CapacidadeExcedidaException, que é obrigatoriamente tratada com try-catch.
        try {
            servidor.alocarContainer(c2);
            System.out.println("Container " + c2.getId() + " alocado com sucesso!");
        } catch (CapacidadeExcedidaException e) {
            System.out.println("Erro tratado: " + e.getMessage());
        }

        // Passo 10: fatura ativa do cliente (servidor ligado, logo R$ 5.50)
        System.out.println("Fatura ativa de " + cliente.getNome() + ": R$ "
                + String.format("%.2f", manager.calcularFaturaAtiva(cliente)));
    }
}
// RA: ______________ (preencha com o seu RA)
