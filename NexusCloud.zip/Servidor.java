import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * POJO Servidor (RN01) + regras de negócio de alocação (RN03) e auditoria (RN04).
 * Identidade lógica: dois servidores são iguais se tiverem o mesmo IP.
 */
public class Servidor {

    // Atributos privados (encapsulamento)
    private String ip;
    private double precoPorHora;
    private double ramTotal;
    private boolean statusLigado;   // o servidor "nasce" desligado (false é o padrão do boolean)

    // RN02: lista cronológica de aplicações, inicializada NA DECLARAÇÃO (evita NullPointerException)
    private List<Container> containers = new ArrayList<>();

    // Construtor conforme o diagrama: (ip, ramTotal, precoPorHora)
    public Servidor(String ip, double ramTotal, double precoPorHora) {
        this.ip = ip;
        this.ramTotal = ramTotal;
        this.precoPorHora = precoPorHora;
        this.statusLigado = false;  // explícito: nasce desligado
    }

    // Liga o servidor
    public void ligar() {
        this.statusLigado = true;
    }

    // Desliga o servidor
    public void desligar() {
        this.statusLigado = false;
    }

    /**
     * RN03 - Motor de alocação com política Fail-Fast:
     * valida TUDO antes de alterar o estado (adicionar na lista).
     *
     * @throws CapacidadeExcedidaException (checked) se faltar RAM - por isso o "throws" na assinatura.
     *         ServidorOfflineException é unchecked e NÃO precisa ser declarada.
     */
    public void alocarContainer(Container c) throws CapacidadeExcedidaException {

        // Validação 1 (Unchecked): servidor desligado
        if (!statusLigado) {
            throw new ServidorOfflineException("Erro: Não é possível alocar containers em um servidor desligado.");
        }

        // Validação 2 (Checked): RAM já em uso + RAM do novo container não pode ultrapassar a RAM total
        if (calcularRamEmUso() + c.getRamNecessaria() > ramTotal) {
            throw new CapacidadeExcedidaException("Falha Crítica: Memória RAM insuficiente no servidor " + ip + ".");
        }

        // Passou nas duas validações: agora sim altera o estado
        containers.add(c);
    }

    /**
     * RN04 - Soma da RAM de todos os containers alocados, usando Streams (sem laço for).
     * stream() -> mapToDouble (extrai a RAM de cada container) -> sum() (soma tudo).
     */
    public double calcularRamEmUso() {
        return containers.stream()
                .mapToDouble(Container::getRamNecessaria)
                .sum();
    }

    // Getters
    public String getIp() {
        return ip;
    }

    public double getPrecoPorHora() {
        return precoPorHora;
    }

    public double getRamTotal() {
        return ramTotal;
    }

    public boolean isStatusLigado() {
        return statusLigado;
    }

    public List<Container> getContainers() {
        return containers;
    }

    // Setters necessários (o status é controlado por ligar()/desligar(), por isso não há setter dele)
    public void setIp(String ip) {
        this.ip = ip;
    }

    public void setPrecoPorHora(double precoPorHora) {
        this.precoPorHora = precoPorHora;
    }

    public void setRamTotal(double ramTotal) {
        this.ramTotal = ramTotal;
    }

    /** equals baseado SOMENTE no IP. */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Servidor outro = (Servidor) obj;
        return Objects.equals(ip, outro.ip);
    }

    /** hashCode coerente com o equals (usa apenas o IP). Necessário para o HashSet<Servidor> não duplicar. */
    @Override
    public int hashCode() {
        return Objects.hash(ip);
    }

    @Override
    public String toString() {
        return "Servidor " + ip + " (" + (statusLigado ? "LIGADO" : "DESLIGADO") + ")";
    }
}
// RA: ______________ (preencha com o seu RA)
