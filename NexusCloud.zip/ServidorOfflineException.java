/**
 * Exceção UNCHECKED (RN03 - regra 1).
 * Estende RuntimeException: o compilador NÃO obriga try-catch nem "throws".
 * Lançada quando tentamos alocar um container em um servidor desligado.
 */
public class ServidorOfflineException extends RuntimeException {

    // Construtor recebe a mensagem e repassa para a classe pai (RuntimeException)
    public ServidorOfflineException(String msg) {
        super(msg);
    }
}
// RA: ______________ (preencha com o seu RA)
