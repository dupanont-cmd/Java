import java.util.Objects;

/**
 * POJO Container (RN01) - uma aplicação rodando dentro de um servidor.
 * Identidade lógica: dois containers são iguais se tiverem o mesmo ID.
 */
public class Container {

    // Atributos privados (encapsulamento)
    private String id;
    private String nomeApp;
    private double ramNecessaria;

    // Construtor conforme o diagrama UML
    public Container(String id, String nomeApp, double ramNecessaria) {
        this.id = id;
        this.nomeApp = nomeApp;
        this.ramNecessaria = ramNecessaria;
    }

    // Getters (o diagrama mostra getId e getRamNecessaria; incluí getNomeApp por completude)
    public String getId() {
        return id;
    }

    public String getNomeApp() {
        return nomeApp;
    }

    public double getRamNecessaria() {
        return ramNecessaria;
    }

    // Setters
    public void setId(String id) {
        this.id = id;
    }

    public void setNomeApp(String nomeApp) {
        this.nomeApp = nomeApp;
    }

    public void setRamNecessaria(double ramNecessaria) {
        this.ramNecessaria = ramNecessaria;
    }

    /** equals baseado SOMENTE no ID. */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Container outro = (Container) obj;
        return Objects.equals(id, outro.id);
    }

    /** hashCode coerente com o equals (usa apenas o ID). */
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return id + " [" + nomeApp + ", " + ramNecessaria + " GB]";
    }
}
// RA: ______________ (preencha com o seu RA)
